# TransactionDocumentList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transactionDocument** | **String** | This is the pdf document displayed/generated against a transaction. This is a reference data field. Please use /v1/utilities/referenceData/{transactionDocument} resource to get valid value of this field with description. |  [optional]
