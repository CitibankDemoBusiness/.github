# ConsentsDetailsUpdateRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountId** | **String** | AccountId | 
**accountConsentDetails** | [**List&lt;AccountConsentDetails&gt;**](AccountConsentDetails.md) |  |  [optional]
