# StatementsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**creditCardStatement** | [**CreditCardStatement**](CreditCardStatement.md) |  |  [optional]
