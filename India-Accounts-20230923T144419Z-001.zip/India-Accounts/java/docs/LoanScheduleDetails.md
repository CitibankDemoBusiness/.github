# LoanScheduleDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**paymentCycleNumber** | **String** | Payment no |  [optional]
**appliedFinancedAmount** | **Double** | Financed amount applied |  [optional]
**appliedInterestAmount** | **Double** | Interest amount applied |  [optional]
**appliedCreditUsageFeeAmount** | **Double** | Credit usage fee amount applied |  [optional]
