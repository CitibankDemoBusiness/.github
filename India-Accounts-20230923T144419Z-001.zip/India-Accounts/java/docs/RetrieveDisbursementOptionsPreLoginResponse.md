# RetrieveDisbursementOptionsPreLoginResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**disbursementOptions** | [**List&lt;DisbursementOptions&gt;**](DisbursementOptions.md) |  |  [optional]
