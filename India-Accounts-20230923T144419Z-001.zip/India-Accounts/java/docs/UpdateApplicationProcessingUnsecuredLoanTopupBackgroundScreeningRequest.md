# UpdateApplicationProcessingUnsecuredLoanTopupBackgroundScreeningRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**applicantDetail** | [**ApplicantDetail**](ApplicantDetail.md) |  |  [optional]
**loanPurpose** | **String** | This field is to indicate the purpose of loan. This is a reference data field.This is a reference data field. Please use /v1/utilities/referenceData/{loanPurpose} resource to get valid value of this field with description. |  [optional]
