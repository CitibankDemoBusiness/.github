# EppLoanBookingResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**eppTransaction** | [**EppTransaction**](EppTransaction.md) |  | 
