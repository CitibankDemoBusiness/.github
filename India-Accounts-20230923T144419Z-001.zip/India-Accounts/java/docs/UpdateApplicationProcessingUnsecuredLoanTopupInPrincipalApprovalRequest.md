# UpdateApplicationProcessingUnsecuredLoanTopupInPrincipalApprovalRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**applicant** | [**Applicant**](Applicant.md) |  |  [optional]
**requestedLoanTopupDecision** | [**RequestedLoanTopupDecision**](RequestedLoanTopupDecision.md) |  |  [optional]
