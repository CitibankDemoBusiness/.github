# RequestedLoanTopupDecision

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**loanOutstandingBalance** | **Double** | Existing loan outstanding balance amount |  [optional]
**loanTopupRecommendations** | [**List&lt;LoanTopupRecommendations&gt;**](LoanTopupRecommendations.md) |  |  [optional]
