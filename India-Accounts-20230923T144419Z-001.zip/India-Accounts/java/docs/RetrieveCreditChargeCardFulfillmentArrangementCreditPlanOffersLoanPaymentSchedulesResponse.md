# RetrieveCreditChargeCardFulfillmentArrangementCreditPlanOffersLoanPaymentSchedulesResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**listResponse** | [**ListResponse**](ListResponse.md) |  |  [optional]
**orgCode** | **String** | Organization of the card |  [optional]
**loanAmortizationSchedule** | [**List&lt;LoanPaymentSchedule&gt;**](LoanPaymentSchedule.md) |  |  [optional]
**loanSummary** | [**LoanSummary**](LoanSummary.md) |  |  [optional]
