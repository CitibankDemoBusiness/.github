# FinancialInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**expenseDetails** | [**List&lt;ExpenseDetails&gt;**](ExpenseDetails.md) |  |  [optional]
**incomeDetails** | [**List&lt;IncomeDetails&gt;**](IncomeDetails.md) |  |  [optional]
