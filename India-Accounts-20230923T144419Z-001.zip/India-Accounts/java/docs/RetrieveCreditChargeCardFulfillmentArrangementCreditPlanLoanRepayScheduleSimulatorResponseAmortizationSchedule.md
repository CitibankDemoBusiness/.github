# RetrieveCreditChargeCardFulfillmentArrangementCreditPlanLoanRepayScheduleSimulatorResponseAmortizationSchedule

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**installmentNumber** | **String** | Installment number | 
**principalAmount** | **Double** | The portion of the Principal Amount Paid for the loan in local currency | 
**installmentInterestAmount** | **Double** | The interest  amount to be paid as installment. | 
