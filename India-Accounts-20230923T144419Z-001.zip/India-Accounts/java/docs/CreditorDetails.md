# CreditorDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**creditorProxyIdType** | **String** | Proxy ID Type used for the payee account identification |  [optional]
**creditorProxyIdValue** | **String** | Proxy ID value used for the payee account identification |  [optional]
