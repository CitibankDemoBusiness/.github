# SufficiencyOfFundsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sufficientFundsIndicator** | **Boolean** | Indicator to indicate if sufficient funds are present in the account for deduction. | 
