# LoanBookingPlanResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**loanBookingPlans** | [**List&lt;LoanBookingPlan&gt;**](LoanBookingPlan.md) |  |  [optional]
