# CreditCheckResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**creditCheck** | [**List&lt;CreditCheck&gt;**](CreditCheck.md) |  | 
