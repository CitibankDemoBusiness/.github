# PartialResponseInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fieldName** | **String** | This refer to the field for which partial failure happened |  [optional]
**reasonCode** | **String** | This refer to reason info of partial failure. |  [optional]
**additionalInformation** | **String** | This refer to additional details of partial failure. |  [optional]
