# RetrieveUnmaskedAccountDataResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accounts** | [**List&lt;Accounts&gt;**](Accounts.md) |  |  [optional]
