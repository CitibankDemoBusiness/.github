# OriginalCreditorDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**originalCreditorName** | **String** | Original Creditor Name |  [optional]
**originalCreditorProxyIdType** | **String** | Proxy ID Type used for the payee account identification |  [optional]
**originalCreditorProxyIdValue** | **String** | Proxy ID value used for the payee account identification |  [optional]
