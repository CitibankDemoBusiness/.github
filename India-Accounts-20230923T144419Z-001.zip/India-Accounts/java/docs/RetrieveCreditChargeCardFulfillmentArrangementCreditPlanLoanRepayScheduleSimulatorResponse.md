# RetrieveCreditChargeCardFulfillmentArrangementCreditPlanLoanRepayScheduleSimulatorResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**effectiveInterestRate** | **Double** | Effective interest rate. |  [optional]
**annualPercentageRate** | **Double** | Applicable Annual Percentage Rate |  [optional]
**totalInterestAmount** | **Double** | Total interest amount on checking account |  [optional]
**amortizationSchedule** | [**RetrieveCreditChargeCardFulfillmentArrangementCreditPlanLoanRepayScheduleSimulatorResponseAmortizationSchedule**](RetrieveCreditChargeCardFulfillmentArrangementCreditPlanLoanRepayScheduleSimulatorResponseAmortizationSchedule.md) |  |  [optional]
