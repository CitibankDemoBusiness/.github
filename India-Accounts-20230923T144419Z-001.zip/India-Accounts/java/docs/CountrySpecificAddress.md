# CountrySpecificAddress

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unitNumber** | **String** | Applicants unit Number |  [optional]
**floorNumber** | **String** | Applicants floor Number |  [optional]
**blockNumber** | **String** | Applicants block Number |  [optional]
**buildingName** | **String** | Applicants building Name |  [optional]
**streetNumber** | **String** | Applicants street Number |  [optional]
**streetName** | **String** | Applicants street Name |  [optional]
**streetType** | **String** | Applicants street Type.Please use /v1/utilities/referenceData/{streetType} resource to get valid value of this field with description. |  [optional]
**town** | **String** | Applicants town |  [optional]
