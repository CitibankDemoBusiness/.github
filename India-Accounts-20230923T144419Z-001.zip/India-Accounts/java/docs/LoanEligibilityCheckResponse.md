# LoanEligibilityCheckResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**loanEligibilityDetails** | [**List&lt;LoanEligibilityDetails&gt;**](LoanEligibilityDetails.md) |  |  [optional]
