# BeneficiaryBankDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fullName** | **String** | Name of the Beneficiary. | 
**displayAccountNumber** | **String** | A masked account number that can be displayed to the customer | 
**bankName** | **String** | Name of the bank. | 
**bankCode** | **String** | The bank code of the external payee account. | 
**accountNumber** | **String** | Account number of the beneficiary. |  [optional]
