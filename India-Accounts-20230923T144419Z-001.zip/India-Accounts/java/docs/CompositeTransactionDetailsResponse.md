# CompositeTransactionDetailsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transactionDetails** | [**List&lt;TransactionDetails&gt;**](TransactionDetails.md) | Composite transaction details |  [optional]
