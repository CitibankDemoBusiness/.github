# LoanTopup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tenor** | **String** | Tenor for the loan repayment.This is a reference data field. Please use /v1/utilities/referenceData/{tenor} resource to get valid values of this field with descriptions. |  [optional]
**interestRate** | **Double** | annualPercentageRate -APR |  [optional]
**installmentAmount** | **Double** | Instalment amount to be paid. |  [optional]
