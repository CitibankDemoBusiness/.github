# ConsentsDetailsInquiryResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountConsentDetails** | [**List&lt;AccountConsentDetails&gt;**](AccountConsentDetails.md) |  |  [optional]
