# LoanBookingConfirmationResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**loanReferenceId** | **String** | Reference Id to uniquely identify the loan. | 
