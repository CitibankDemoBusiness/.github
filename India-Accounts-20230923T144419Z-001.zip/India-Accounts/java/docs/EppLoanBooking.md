# EppLoanBooking

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**loanAmount** | **Double** | Loan amount for easy payment plan booking. | 
**referenceId** | **String** | Reference Id to uniquely identify the transaction. Applicable only for EPP of type TRANSACTION. |  [optional]
**transactionAuthorizationCode** | **String** | Transaction authorization code is a unique to a sales credit card transaction to indicate that the sale has been authorized. |  [optional]
