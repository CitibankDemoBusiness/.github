# RetrieveUnmaskedAccountDataRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accountInfo** | [**List&lt;AccountInfo&gt;**](AccountInfo.md) |  |  [optional]
