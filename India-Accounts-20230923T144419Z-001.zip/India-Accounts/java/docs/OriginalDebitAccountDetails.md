# OriginalDebitAccountDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**displayAccountNumber** | **String** | A masked account number that can be displayed to the customer |  [optional]
**bankName** | **String** | Name of the bank. |  [optional]
**bankCode** | **String** | The bank code of the payee account |  [optional]
