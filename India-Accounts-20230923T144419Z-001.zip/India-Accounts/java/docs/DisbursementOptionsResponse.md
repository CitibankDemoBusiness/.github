# DisbursementOptionsResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**disbursementOptions** | [**List&lt;DisbursementOption&gt;**](DisbursementOption.md) |  | 
