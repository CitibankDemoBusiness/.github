# InitiateCreditChargeCardFulfillmentArrangementCreditPlanEppLoanCreationResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nextInstallmentAmount** | **Double** | Next installment Amount for the loan |  [optional]
**interestRate** | **Double** | Interest Rate for the loan |  [optional]
**initialFee** | **Double** | Initial Fees for the loan |  [optional]
