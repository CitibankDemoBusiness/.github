# UpdateApplicationProcessingUnsecuredLoanTopupBackgroundScreeningResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**applicationStage** | **String** | Current stage of an application.This is a reference data field. Please use /v1/utilities/referenceData/{applicationStage} resource to get possible value of this field with description. | 
