# CompositeTransactionDetailsRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transactionDetailsRequest** | [**List&lt;TransactionDetailsRequest&gt;**](TransactionDetailsRequest.md) |  |  [optional]
