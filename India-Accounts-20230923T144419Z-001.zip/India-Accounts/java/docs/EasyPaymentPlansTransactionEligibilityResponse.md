# EasyPaymentPlansTransactionEligibilityResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**easyPaymentPlan** | [**List&lt;EasyPaymentPlan&gt;**](EasyPaymentPlan.md) |  |  [optional]
