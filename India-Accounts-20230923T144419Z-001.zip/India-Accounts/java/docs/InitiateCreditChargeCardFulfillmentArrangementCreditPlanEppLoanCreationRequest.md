# InitiateCreditChargeCardFulfillmentArrangementCreditPlanEppLoanCreationRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**transactionId** | **String** | Transaction ID of the debit card transaction for which LOP booking will be done on the credit card |  [optional]
**loanAmount** | **Double** | Eligible Loan amount | 
**loanTenor** | **Integer** | Tenure for the Loan | 
